package grafp2;

public class Guard {
	int i, j;

	public Guard(int i, int j) {
		this.i = i;
		this.j = j;
	}

}
